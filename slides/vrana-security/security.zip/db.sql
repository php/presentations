CREATE DATABASE security;
USE security;

CREATE TABLE authors (
	login varchar(20) NOT NULL,
	password_sha1 char(40) NOT NULL,
	PRIMARY KEY (login)
);
INSERT INTO authors VALUES ('Jakub', '37fa265330ad83eaa879efb1e2db6380896cf639');
INSERT INTO authors VALUES ('Bob', '37fa265330ad83eaa879efb1e2db6380896cf639');

CREATE TABLE comments (
	id int NOT NULL AUTO_INCREMENT,
	login varchar(20) NOT NULL,
	comment text NOT NULL,
	added datetime NOT NULL,
	INDEX (added),
	PRIMARY KEY (id)
);

CREATE TABLE cookies (
	cookie varchar(100) NOT NULL,
	login varchar(20) NOT NULL,
	added datetime NOT NULL,
	PRIMARY KEY (cookie)
);
