<?php
if ($_POST) {
	mysql_query("UPDATE security.authors SET password_sha1 = SHA1('$_POST[new_password]') WHERE login = '$_POST[login]' AND password_sha1 = SHA1('$_POST[old_password]')");
	echo mysql_affected_rows() . " affected row(s).\n";
}
?>
<h1>Password change</h1>
<form action="" method="post">
Login: <input name="login" />
Old Password: <input type="password" name="old_password" />
New Password: <input type="password" name="new_password" />
<input type="submit" value="Change Password" />
</form>
