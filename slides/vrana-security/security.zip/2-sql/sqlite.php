<?php
$sqlite = new SQLiteDatabase("../db.sqlite");
if ($_POST) {
	$sqlite->query("UPDATE authors SET password_sha1 = '" . sha1($_POST["new_password"]) . "' WHERE login = '$_POST[login]' AND password_sha1 = '" . sha1($_POST["old_password"]) . "'");
	echo $sqlite->changes() . " change(s).\n";
}
?>
<h3>Password change</h3>
<form action="" method="post">
Login: <input name="login" />
Old Password: <input type="password" name="old_password" />
New Password: <input type="password" name="new_password" />
<input type="submit" value="Change Password" />
</form>
