<?php
$offset = (isset($_GET["offset"]) ? mysql_real_escape_string($_GET["offset"]) : 0);
$result = mysql_query("SELECT * FROM security.comments ORDER BY added DESC LIMIT 10 OFFSET $offset");
echo mysql_error();
while ($row = mysql_fetch_assoc($result)) {
	echo "<p><b>$row[login]:</b> $row[comment]</p>\n";
}
