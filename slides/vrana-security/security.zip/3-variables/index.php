<?php
if ($password == "pwd") {
	$auth = true;
}
if ($auth) {
	echo "Secret information.\n";
} else {
	?>
	<form action="" method="post">
	Password: <input type="password" name="password">
	<input type="submit" value="Login">
	</form>
	<?php
}
?>
