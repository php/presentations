<ul>
<li><a href=".">Home</a></li>
<li><a href="?page=secure.php">Secure page</a></li>
</ul>

<?php
$auth = ($_POST["password"] == "pwd");
include ($_GET["page"] ? $_GET["page"] : "home.php");
?>
