<?php
if ($auth) { // set in index.php
	echo "Secret information.\n";
} else {
	?>
	<form action="" method="post">
	Password: <input type="password" name="password" />
	<input type="submit" value="Log in" />
	</form>
	<?php
}
?>
