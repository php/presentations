<?php
session_start();
mysql_select_db("security");
if (!empty($_POST["login"]) && (isset($_POST["register"])
	? mysql_query("INSERT INTO authors (login, password_sha1) VALUES ('" . mysql_real_escape_string($_POST["login"]) . "', '" . sha1($_POST["password"]) . "')")
	: mysql_result(mysql_query("SELECT COUNT(*) FROM authors WHERE login = '" . mysql_real_escape_string($_POST["login"]) . "' AND password_sha1 = '" . sha1($_POST["password"]) . "'"), 0)
)) {
	$_SESSION["login"] = $_POST["login"];
}
if (!isset($_SESSION["login"])) {
	if (isset($_POST["login"])) {
		echo "<p>" . (!isset($_POST["register"]) ? "Invalid login or password." : "Login is already in use.") . "</p>\n";
	}
	?>
	<form action="" method="post">
	Login: <input name="login" maxlength="20" />
	Password: <input type="password" name="password" />
	<input type="submit" value="Log in" />
	<input type="submit" name="register" value="Register" />
	</form>
	<?php
	exit;
}
