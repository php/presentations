<?php
include "./auth.inc.php";
if (isset($_POST["comment"])) {
	mysql_query("INSERT INTO comments (login, comment, added) VALUES ('" . mysql_real_escape_string($_SESSION["login"]) . "', '" . mysql_real_escape_string($_POST["comment"]) . "', NOW())");
	header("Location: .");
	exit;
}
echo "<h3 id='login'>$_SESSION[login]</h3>\n";
$result = mysql_query("SELECT * FROM comments ORDER BY added DESC LIMIT 20");
while ($row = mysql_fetch_assoc($result)) {
	echo "<p><b>$row[login]:</b> $row[comment]</p>\n";
}
?>
<hr />
<form action="" method="post">
<p><textarea name="comment" rows="5" cols="40"></textarea></p>
<p><input type="submit" value="Insert" /></p>
</form>
