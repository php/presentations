<?php
include "./auth.inc.php";
if (isset($_POST["comment"])) {
	mysql_query("INSERT INTO comments (login, comment, added) VALUES ('" . mysql_real_escape_string($_SESSION["login"]) . "', '" . mysql_real_escape_string($_POST["comment"]) . "', NOW())");
	header("Location: strip_tags.php");
	exit;
}
echo "<h3 id='login'>$_SESSION[login]</h3>\n";
$result = mysql_query("SELECT * FROM comments ORDER BY added DESC LIMIT 20");
while ($row = mysql_fetch_assoc($result)) {
	echo "<p><b>$row[login]:</b> " . strip_tags($row["comment"], "<strong><em>") . "</p>\n";
}
?>
<hr />
<form action="" method="post">
<p><textarea name="comment" rows="5" cols="40"></textarea></p>
<p>Only <kbd>&lt;strong&gt;</kbd> and <kbd>&lt;em&gt;</kbd> tags are allowed.</p>
<p><input type="submit" value="Insert" /></p>
</form>
