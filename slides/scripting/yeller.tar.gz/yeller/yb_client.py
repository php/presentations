#!/usr/bin/env python

import SOAP
import urllib

server = SOAP.SOAPProxy("http://localhost:8080/")
url = server.get_resource({"listing" : "Village Pizza and Pasta", "town" : "Mamaroneck", "state" : "NY"})
res = urllib.urlopen(url)
content = res.read()
print server.get_info(content)
