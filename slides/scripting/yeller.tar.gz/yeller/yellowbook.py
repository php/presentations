#!/usr/bin/env python

import SOAP
import urllib
import re
from pprint import pprint

class YellowPages:
	linktpl="http://yp111.superpages.com/listings.phtml?SRC=&STYPE=S&PG=L&CB=&C=&N=%s&T=%s&S=%s"

	def get_resource(self, attrs):
		return self.linktpl % (urllib.quote(attrs['listing']), urllib.quote(attrs['town']), urllib.quote(attrs['state'])) 

	def get_info(self, content):
		pattern = re.compile(r'<td align=left valign=top ><font face="geneva,arial,helvetica">', re.I)
		match = pattern.search(content)
		if match == None:
			return

		start = match.end()

		pattern = re.compile(r'<font face="geneva,arial,helvetica" size="-1"><a HREF="', re.I)
		match = pattern.search(content[start:])
		if match == None:
			return

		end = match.start() + start

		return content[start:end]


y = YellowPages()

server = SOAP.SOAPServer(("localhost", 8080))
server.registerObject(y)
server.serve_forever()
